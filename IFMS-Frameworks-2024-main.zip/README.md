# frameworks1-2024
repositório destinado a turma de FRAMEWORKS 1C Turma 20241096205C
